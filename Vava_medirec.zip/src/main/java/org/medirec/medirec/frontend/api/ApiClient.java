package org.medirec.medirec.frontend.api;

public class ApiClient {}
